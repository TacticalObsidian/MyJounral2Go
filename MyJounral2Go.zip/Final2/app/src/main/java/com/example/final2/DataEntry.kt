package com.example.final2

import java.io.Serializable

data class DataEntry(

    val Id : Int,
    val Title : String,
    val Day : String,
    val Month : String,
    val Year : String,
    val Hour : String,
    val Minute : String,
    val City : String,
    val Country : String,
    val Entry : String,
) : Serializable
