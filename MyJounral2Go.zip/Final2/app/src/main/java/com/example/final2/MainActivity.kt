package com.example.final2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : AppCompatActivity(), EntryListAdapter.OnItemClickListener {
    private lateinit var entryList: List<DataEntry>
    private lateinit var entryRecycler : RecyclerView
    private val appDatabase = AppDatabase(this, null)
    
    //Create activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //Set up view
        setContentView(R.layout.activity_main)
        entryRecycler = findViewById<RecyclerView>(R.id.recyclerView)
        entryList = appDatabase.getAllEntries() //Retrieve database entries
        val adapter = EntryListAdapter(entryList, this) // Pass 'this' as the listener

        entryRecycler.adapter = adapter
        entryRecycler.layoutManager = LinearLayoutManager(this)

        // Create New Entry
        val addBtn: ImageButton = findViewById(R.id.AddBtn)
        addBtn.setOnClickListener {
            val intent = Intent(this, AddEditActivity::class.java)
            intent.putExtra("STATE", 0)
            startActivity(intent)
            finish()
        }
    }

    //FUNCTIONS
    override fun onItemClick(position: Int) {
        // Receives the selected entry via position
        val entry = entryList[position]

        // Display content of selected journal : Pass to ViewManager Activity via EntryId.
        val intent = Intent(this, ViewManager::class.java).apply {
            putExtra("ENTRY_ID", entry.Id)
        }
        startActivity(intent)
        finish()
    }

    //To update the list for recycler view item generation
    override fun onResume() {
        super.onResume()
        entryList = appDatabase.getAllEntries()

        appDatabase.logAllEntries()

        val adapter = EntryListAdapter(entryList, this) // Pass 'this' as the listener
        entryRecycler.adapter = adapter
        entryRecycler.layoutManager = LinearLayoutManager(this)
    }
}
