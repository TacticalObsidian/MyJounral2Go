package com.example.final2

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class AppDatabase(context: Context, factory: SQLiteDatabase.CursorFactory?):
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION){

    override fun onCreate(db: SQLiteDatabase) {
        try {
            // Create ENTRIES_TABLE
            val entriesTableCreate =
                ("CREATE TABLE $TABLE_NAME ("
                        + "$PK_COL INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "$TITLE_COL TEXT, "
                        + "$ENTRY_COL TEXT, "
                        + "$CITY_COL TEXT, "
                        + "$COUNTRY_COL TEXT, "
                        + "$DATE_COL TEXT, "
                        + "$TIME_COL TEXT)")

            db.execSQL(entriesTableCreate)
            Log.d("Database", "Tables created successfully")
        } catch (e: Exception) {
            Log.e("Database", "Error creating tables: ${e.message}")
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.let {
            try {
                it.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
                it.execSQL("DROP TABLE IF EXISTS $TABLE_NAME2")
                onCreate(it)
                Log.d("Database", "Tables upgraded successfully")
            } catch (e: Exception) {
                Log.e("Database", "Error upgrading tables: ${e.message}")
            }
        }
    }

    //METHODS: ENTRIES TABLE
    fun addEntry(title : String, entry : String, city: String, country : String, date : String, time : String) : Long{
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(TITLE_COL, title)
            put(ENTRY_COL, entry)
            put(CITY_COL, city)
            put(COUNTRY_COL, country)
            put(DATE_COL, date)
            put(TIME_COL, time)
        }

        val rowId = db.insert(TABLE_NAME, null, values)
        db.close()
        return rowId
    }

    fun getAllEntries(): List<DataEntry> {
        val entries = mutableListOf<DataEntry>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)

        if (cursor.moveToFirst()) {
            do {
                val entry = DataEntry(
                    Id = cursor.getInt(cursor.getColumnIndexOrThrow(PK_COL)),
                    Title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL)),
                    Day = cursor.getString(cursor.getColumnIndexOrThrow(DATE_COL)).split("/")[0],
                    Month = cursor.getString(cursor.getColumnIndexOrThrow(DATE_COL)).split("/")[1],
                    Year = cursor.getString(cursor.getColumnIndexOrThrow(DATE_COL)).split("/")[2],
                    Hour = cursor.getString(cursor.getColumnIndexOrThrow(TIME_COL)).split(":")[0],
                    Minute = cursor.getString(cursor.getColumnIndexOrThrow(TIME_COL)).split(":")[1],
                    City = cursor.getString(cursor.getColumnIndexOrThrow(CITY_COL)),
                    Country = cursor.getString(cursor.getColumnIndexOrThrow(COUNTRY_COL)),
                    Entry = cursor.getString(cursor.getColumnIndexOrThrow(ENTRY_COL))
                )
                entries.add(entry)
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return entries
    }

    fun getEntryByID(entryID: Int): DataEntry? {
        val db = readableDatabase
        val cursor = db.query(TABLE_NAME, null, "$PK_COL=?", arrayOf(entryID.toString()), null, null, null)

        val entry = if (cursor.moveToFirst()) {
            val dateParts = cursor.getString(cursor.getColumnIndexOrThrow(DATE_COL)).split("/")
            val timeParts = cursor.getString(cursor.getColumnIndexOrThrow(TIME_COL)).split(":")

            DataEntry(
                Id = cursor.getInt(cursor.getColumnIndexOrThrow(PK_COL)),
                Title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL)),
                Entry = cursor.getString(cursor.getColumnIndexOrThrow(ENTRY_COL)),
                City = cursor.getString(cursor.getColumnIndexOrThrow(CITY_COL)),
                Country = cursor.getString(cursor.getColumnIndexOrThrow(COUNTRY_COL)),
                Day = dateParts[0],
                Month = dateParts[1],
                Year = dateParts[2],
                Hour = timeParts[0],
                Minute = timeParts[1]
            )
        } else {
            null
        }
        cursor.close()
        db.close()

        Log.d("Database", "Retrieved Entry: $entry")  // Log the retrieved entry
        return entry
    }


    fun deleteEntryByID(entryID: Int) {
        val db = writableDatabase
        val whereClause = "$PK_COL = ?"
        val whereArgs = arrayOf(entryID.toString())
        val rowsAffected = db.delete(TABLE_NAME, whereClause, whereArgs)
        Log.d("Database", "Rows deleted: $rowsAffected") // Log the number of rows deleted
        db.close()
    }

    fun editEntry(entryID: Int, title : String, entry : String, city: String, country : String, date : String, time : String){
        val db = writableDatabase
        val values = ContentValues().apply {
            put(TITLE_COL, title)
            put(ENTRY_COL, entry)
            put(CITY_COL, city)
            put(COUNTRY_COL, country)
            put(DATE_COL, date)
            put(TIME_COL, time)
        }

        val whereClause = "$PK_COL = ?"
        val whereArgs = arrayOf(entryID.toString())
        db.update(TABLE_NAME, values, whereClause, whereArgs)
        db.close()
    }

    fun logAllEntries() {
        val entries = getAllEntries()
        entries.forEach { entry ->
            Log.d("Database", "Entry: ${entry.Id}, ${entry.Title}, ${entry.Entry}")
        }
    }
    companion object {
        private const val DATABASE_NAME = "ENTRIES"
        private const val DATABASE_VERSION = 3

        private const val TABLE_NAME = "ENTRIES_TABLE"
        private const val TABLE_NAME2 = "JOURNAL_TABLE"

        //COLUMNS FOR ENTRIES
        const val PK_COL = "id"
        const val TITLE_COL = "title"
        const val ENTRY_COL = "entry"
        const val CITY_COL = "city"
        const val COUNTRY_COL = "country"
        const val DATE_COL = "date"
        const val TIME_COL = "time"
    }

}

