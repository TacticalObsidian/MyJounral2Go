package com.example.final2

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import android.content.Intent
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class AddEditActivity : AppCompatActivity() {

    // Declare view variables
    private lateinit var submitBtn: ImageButton
    private lateinit var cancelBtn: ImageButton
    private lateinit var addImageBtn: ImageButton

    private lateinit var addTitle: EditText
    private lateinit var addCity: EditText
    private lateinit var addCountry: EditText
    private lateinit var editDate: TextView
    private lateinit var editTime: TextView
    private lateinit var addRecordDescription: EditText

    private lateinit var showWhenBlank: TextView
    private lateinit var entry : DataEntry

    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_add_entry)

        val appDatabase = AppDatabase(this, null)

        //TO EDIT/ADD NEW ENTRY
        val iD = intent.getIntExtra("ENTRY_ID", -1)

        // Initialize views
        submitBtn = findViewById(R.id.submitBtn)
        cancelBtn = findViewById(R.id.cancelBtn)
        addTitle = findViewById(R.id.record_title_edit)
        addCity = findViewById(R.id.record_city_edit)
        addCountry = findViewById(R.id.record_country_edit)
        editDate = findViewById(R.id.record_date_edit)
        editTime = findViewById(R.id.record_time_edit)
        addImageBtn = findViewById(R.id.AddImageBtn)
        showWhenBlank = findViewById(R.id.showWhenBlank)
        addRecordDescription = findViewById(R.id.RecordDescription)

        //Bind data to views
        if (iD == -1) {
            //Leave else to be blank and use current date for date and time.
            setCurrentDateTime()
        }

        if (iD != -1) {
            // Pull all values from the database for the current entry using the entry ID.
            val entryNullable = appDatabase.getEntryByID(iD)
            if (entryNullable == null) {
                Toast.makeText(this, "Entry not found", Toast.LENGTH_SHORT).show()
                finish()
                return
            }

            entry = entryNullable

            // Bind data to views
            addTitle.setText(entry.Title)
            addCity.setText(entry.City)
            addCountry.setText(entry.Country)
            addRecordDescription.setText(entry.Entry)
            editDate.setText("${entry.Day}/${entry.Month}/${entry.Year}")
            editTime.setText("${entry.Hour}:${entry.Minute}")
        }

        // Set up click listeners
        submitBtn.setOnClickListener {
            if(iD == -1){
                val result = appDatabase.addEntry(addTitle.text.toString(), addRecordDescription.text.toString(), addCity.text.toString(), addCountry.text.toString(), editDate.text.toString(), editTime.text.toString())

                if (result != -1L) { // Check if the insert was successful
                    Toast.makeText(this, "Added Record Successfully!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    //Return to MainActivity
                    startActivity(intent)
                    finish()
                }
                else {
                    Toast.makeText(this, "Failed to Add Record", Toast.LENGTH_SHORT).show()
                }

            }
            else{
                appDatabase.editEntry(iD, addTitle.text.toString(), addRecordDescription.text.toString(), addCity.text.toString(), addCountry.text.toString(), editDate.text.toString(), editTime.text.toString())
            }
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        cancelBtn.setOnClickListener {
            showConfirmationDialog()
        }

        //Convert Date and Time textViews into a make-shift button.
        editDate.setOnClickListener {
            startDatePicker()
        }

        editTime.setOnClickListener {
            startTimePicker()
        }
    }

    //Set current date and time for a new entry. Else, always display past date.
    private fun setCurrentDateTime() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val currentDate = dateFormat.format(calendar.time)
        editDate.text = currentDate

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentTime = timeFormat.format(calendar.time)
        editTime.text = currentTime
    }

    fun startDatePicker() {
        val DatePickerDialog = DatePickerDialog(
            this, { DatePicker, year: Int, month: Int, day: Int ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, day)
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val formattedDate = dateFormat.format(selectedDate.time)

                editDate.text = formattedDate
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        DatePickerDialog.show()
    }

    fun startTimePicker() {
        val selectedTime = Calendar.getInstance()
        val TimePickerInstance = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
            selectedTime.set(Calendar.HOUR_OF_DAY, hour)
            selectedTime.set(Calendar.MINUTE, minute)
            editTime.text = SimpleDateFormat("HH:mm").format(selectedTime.time)
        }
        TimePickerDialog(
            this, TimePickerInstance, selectedTime.get(Calendar.HOUR_OF_DAY), selectedTime.get(
                Calendar.MINUTE
            ), false
        ).show()
    }

    //Two-step user verification when cancelling update/adding
    private fun showConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Wait a moment!")
        builder.setMessage("Are you sure you want to discard your changes?")

        builder.setPositiveButton("Yes") { dialog, which ->
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            Toast.makeText(this, "Activity Cancelled", Toast.LENGTH_SHORT).show()
            finish() //Prevent backtracking and release resources
        }

        builder.setNegativeButton("No") { dialog, which ->
            Toast.makeText(this, "Activity Persists", Toast.LENGTH_SHORT).show()
        }

        val dialog = builder.create()
        dialog.show()
    }

    override fun onBackPressed() {
        showConfirmationDialog()
    }
}
