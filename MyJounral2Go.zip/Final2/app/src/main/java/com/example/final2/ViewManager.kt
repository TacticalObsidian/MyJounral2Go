package com.example.final2

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageButton
import android.widget.Toast

class ViewManager : AppCompatActivity() {

    //CLASS ATTRIBUTES
    private lateinit var returnBtn: ImageButton
    private lateinit var deleteEntryBtn: ImageButton
    private lateinit var editEntryBtn: ImageButton
    private lateinit var recordTitle: TextView
    private lateinit var recordLocation: TextView
    private lateinit var recordDate: TextView
    private lateinit var recordTime: TextView
    private lateinit var recordDescription: TextView
    private lateinit var showWhenBlank: TextView

    private val appDatabase = AppDatabase(this, null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entry_view)

        //Declare variables
        returnBtn = findViewById(R.id.ReturnBtn)
        deleteEntryBtn = findViewById(R.id.DeleteEntry)
        editEntryBtn = findViewById(R.id.EditEntry)

        recordTitle = findViewById(R.id.RecordTitle)
        recordLocation = findViewById(R.id.RecordLocation)
        recordDate = findViewById(R.id.RecordDate)
        recordTime = findViewById(R.id.RecordTime)
        recordDescription = findViewById(R.id.RecordDescription)
        showWhenBlank = findViewById(R.id.showWhenBlank)


        // Pull the intent values
        val entryID = intent.getIntExtra("ENTRY_ID", -1)

        if (entryID != -1) {
            val entry = appDatabase.getEntryByID(entryID)
            if (entry != null) {
                // Bind data to views
                recordTitle.text = entry.Title
                recordDate.text = "${entry.Day}/${entry.Month}/${entry.Year}"
                recordTime.text = "${entry.Hour}:${entry.Minute}"
                recordDescription.text = entry.Entry
                recordLocation.text = "${entry.City}, ${entry.Country}"
            } else {
                Toast.makeText(this, "Entry not found", Toast.LENGTH_SHORT).show()
                finish()  // Exit activity if entry is not found
            }
        } else {
            Toast.makeText(this, "Invalid Entry ID", Toast.LENGTH_SHORT).show()
            finish()  // Exit activity if entry ID is invalid
        }

        //Set on click listeners for buttons
        /*
        * Edit - To Edit/New
        * Delete - Return to main and delete record
        * Return - Just return to main
        * */
        editEntryBtn.setOnClickListener {
            showConfirmationDialog(0)
        }

        deleteEntryBtn.setOnClickListener {
            showConfirmationDialog(1)
        }

        returnBtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    //Two-step user verification when deciding to update entry
    private fun showConfirmationDialog(context: Int) {
        //TO get the ID to be deleted/Edited
        val entryID = intent.getIntExtra("ENTRY_ID", 0)

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Wait a moment!")
        when (context) {
            //Edit
            0 -> {
                builder.setMessage("Are you sure you want to edit the entry? Don't worry! Even if you click yes, you can always return back to the original one as long as the changes were saved.")
                builder.setPositiveButton("Yes") { dialog, which ->
                    val intent = Intent(this, AddEditActivity::class.java).apply {
                        putExtra("ENTRY_ID", entryID)
                    }

                    startActivity(intent)
                    Toast.makeText(this, "Entry opened for editing", Toast.LENGTH_SHORT).show()
                    finish() //Prevent backtracking and release resources
                }
                builder.setNegativeButton("No") { dialog, which ->
                    Toast.makeText(this, "Entry editing discarded", Toast.LENGTH_SHORT).show()
                }
            }

            //Delete
            1 -> {
                builder.setMessage("Are you sure you want to delete the entry? This cannot be undone!")
                builder.setPositiveButton("Yes") { dialog, which ->
                    val intent = Intent(this, MainActivity::class.java)
                    //TO DELETE THE ENTRY
                    appDatabase.deleteEntryByID(entryID)

                    startActivity(intent)
                    Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
                    finish() //Prevent backtracking and release resources
                }
                builder.setNegativeButton("No") { dialog, which ->
                    Toast.makeText(this, "Entry delete discarded", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val dialog = builder.create()
        dialog.show()
    }

    //MAKE SURE USERS CAN ONLY RETURN TO MAINACTIVITY.Kt
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}