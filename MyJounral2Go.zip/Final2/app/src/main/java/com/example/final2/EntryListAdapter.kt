package com.example.final2

import android.view.LayoutInflater
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntryListAdapter(private val entryList: List<DataEntry>, private val listener: OnItemClickListener)
    : RecyclerView.Adapter<EntryListAdapter.EntryViewHolder>() {

    inner class EntryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val RecordTitle: TextView = view.findViewById(R.id.record_name)
        val RecordLocation: TextView = view.findViewById(R.id.record_location)
        val RecordTimeStamp: TextView = view.findViewById(R.id.record_timestamp)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(position)
                }
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycled_entry, parent, false)
        return EntryViewHolder(view)
    }

    override fun onBindViewHolder(holder: EntryViewHolder, position: Int) {
        val entry = entryList[position]
        holder.RecordTitle.text = entry.Title
        holder.RecordLocation.text = "${entry.City}, ${entry.Country}"
        holder.RecordTimeStamp.text = "${entry.Day}/${entry.Month}/${entry.Year}, ${entry.Hour}:${entry.Minute}"
    }

    override fun getItemCount() = entryList.size
}